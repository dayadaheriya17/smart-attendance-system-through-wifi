# Smart Attendance System Android App

## Description

This app simplifies the process of taking attendance. Students can register thier attendance by connecting to wifi hotspot created by 
their teachers using this app. App automatically stores the attendance to the server which can then be viewed by both teachers and students.


## Screenshots

<img src="/screenshots/Screenshot_20190930-225549.png" alt="alt text" width="250">  <img src="/screenshots/Screenshot_20190930-225558.png" alt="alt text" width="250">
<img src="/screenshots/Screenshot_20190930-225613.png" alt="alt text" width="250">
<img src="/screenshots/Screenshot_20190930-230020.png" alt="alt text" width="250">
<img src="/screenshots/Screenshot_20190930-230038.png" alt="alt text" width="250">
